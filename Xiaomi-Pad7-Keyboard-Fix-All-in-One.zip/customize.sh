#!/system/bin/sh
[ "$BOOTMODE" = true ] || abort 'Install this ZIP from the Magisk app.'
[ "$ARCH" = arm64 ] || abort 'The supplied keyboard binaries require ARM64.'
[ -e /dev/nanodev0 ] || abort 'Missing /dev/nanodev0: this ROM/kernel does not expose the required keyboard driver.'
STATE=/data/adb/.pad7_keyboard_bundle
[ ! -L "$STATE" ] || abort 'Backup directory must not be a symlink.'
mkdir -p "$STATE" || abort 'Cannot create keyboard backup directory.'
chmod 700 "$STATE"

# Stage a list rooted at /data. No unrelated adb files are ever copied.
: > "$MODPATH/managed.list"
while read -r mode rel; do
  echo "$mode adb/$rel" >> "$MODPATH/managed.list"
done < "$MODPATH/files.list"
echo '0644 system/devices/idc/Vendor_15d9_Product_00a3.idc' >> "$MODPATH/managed.list"

# Reject symlinks and non-file destinations before taking backups or writing.
while read -r mode rel; do
  target=/data/$rel
  [ ! -e "$target" ] || [ -f "$target" ] || abort "Not a regular file: $target"
  check=$target
  while [ "$check" != / ]; do
    [ ! -L "$check" ] || abort "Symlink in destination path: $check"
    check=${check%/*}; [ -n "$check" ] || check=/
  done
done < "$MODPATH/managed.list"

TXN="$TMPDIR/pad7-keyboard-rollback"
rm -rf "$TXN"
mkdir -p "$TXN" || abort 'Cannot create temporary backup.'
while read -r mode rel; do
  if [ -f "/data/$rel" ]; then
    mkdir -p "$TXN/${rel%/*}" || abort 'Cannot prepare temporary backup.'
    cp -p "/data/$rel" "$TXN/$rel" || abort 'Cannot back up current keyboard files.'
  fi
done < "$MODPATH/managed.list"

NEW_STATE=0
if [ ! -f "$STATE/ready" ]; then
  NEW_STATE=1
  rm -rf "$STATE/backup"
  mkdir -p "$STATE/backup" || abort 'Cannot prepare original backup.'
  cp -Rp "$TXN/." "$STATE/backup/" || abort 'Cannot save original keyboard files.'
  cp "$MODPATH/managed.list" "$STATE/managed.list" || abort 'Cannot save file list.'
  touch "$STATE/ready" || abort 'Cannot complete original backup.'
fi

rollback() {
  while read -r mode rel; do
    if [ -f "$TXN/$rel" ]; then
      cp -p "$TXN/$rel" "/data/$rel"
    else
      rm -f "/data/$rel"
    fi
  done < "$MODPATH/managed.list"
  [ "$NEW_STATE" = 0 ] || rm -rf "$STATE"
  abort 'Keyboard file installation failed; previous files were restored. Check free space.'
}
mkdir -p "$TXN/new-owned" || rollback
while read -r mode rel; do
  case "$rel" in
    adb/*) src="$MODPATH/payload/${rel#adb/}" ;;
    system/*) src="$TXN/keyboard.idc"
      printf '%s\n' 'keyboard.orientationAware = 0' 'keyboard.builtIn = 0' 'device.internal = 0' > "$src" || rollback ;;
  esac
  target=/data/$rel
  mkdir -p "${target%/*}" "$TXN/new-owned/${rel%/*}" || rollback
  cp "$src" "$target" || rollback
  chown 0:0 "$target" || rollback
  chmod "$mode" "$target" || rollback
  # Match labels used for root-owned Magisk data payloads; do not change policy.
  case "$rel" in
    adb/*) chcon u:object_r:magisk_file:s0 "$target" 2>/dev/null || rollback ;;
    system/*) restorecon "$target" 2>/dev/null ;;
  esac
  cp "$src" "$TXN/new-owned/$rel" || rollback
done < "$MODPATH/managed.list"
mkdir -p /data/adb/kbd || rollback
# Commit the expected contents used by uninstall to protect later user edits.
rm -rf "$STATE/owned.new"
cp -R "$TXN/new-owned" "$STATE/owned.new" || rollback
rm -rf "$STATE/owned"
mv "$STATE/owned.new" "$STATE/owned" || rollback
chmod 700 "$STATE"
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
# Reapply and verify the external modes after module permission setup.
MODDIR=$MODPATH
. "$MODPATH/repair-permissions.sh" || rollback
ui_print 'Keyboard files installed; executable permissions verified.'
ui_print 'Boot-time permission repair enabled; no hidden marker needed.' 
ui_print 'Original BasicFix is now included in this one module.'
ui_print 'CPU guard/watchdog and unrelated modules are excluded.'
ui_print 'Reboot now to activate the complete keyboard fix.'
