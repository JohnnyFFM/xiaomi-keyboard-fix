#!/system/bin/sh
MODDIR=${0%/*}
mkdir -p /data/adb/kbd || exit 1
# Module hooks still execute when external service.d files have lost +x.
# Fix all payload modes before Magisk reaches the late-start service stage.
if ! . "$MODDIR/repair-permissions.sh" >> /data/adb/kbd/bundle.log 2>&1; then
  echo 'Keyboard startup: permission repair failed.' >> /data/adb/kbd/bundle.log
  exit 1
fi
echo 'Keyboard startup: executable permissions ready (v2.1).' >> /data/adb/kbd/bundle.log
# General post-fs-data hooks run earlier. Apply the same IDC now as well so
# a lost executable bit cannot skip it on the first repaired boot.
sh /data/adb/post-fs-data.d/kbd_idc.sh
sh /data/adb/post-fs-data.d/post-fs-data-kbd-idc.sh
# Preserve the original BasicFix delayed rebind and SurfaceFlinger action.
sh "$MODDIR/original-basicfix/post-fs-data.sh"
