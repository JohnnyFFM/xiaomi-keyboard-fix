#!/system/bin/sh
# Sourced from the installer and module post-fs-data hook. No hardware actions.
repair_keyboard_permissions() {
  while read -r kbd_mode kbd_rel; do
    kbd_target=/data/adb/$kbd_rel
    kbd_check=$kbd_target
    while [ "$kbd_check" != / ]; do
      if [ -L "$kbd_check" ]; then
        echo "Keyboard permission repair: refusing symlink $kbd_check"
        return 1
      fi
      kbd_check=${kbd_check%/*}; [ -n "$kbd_check" ] || kbd_check=/
    done
    if [ ! -f "$kbd_target" ]; then
      echo "Keyboard permission repair: missing $kbd_target; reinstall the ZIP."
      return 1
    fi
    chown 0:0 "$kbd_target" && chmod "$kbd_mode" "$kbd_target" || return 1
    case "$kbd_mode" in
      0755) [ -x "$kbd_target" ] || return 1 ;;
    esac
  done < "$MODDIR/files.list"
}
repair_keyboard_permissions
