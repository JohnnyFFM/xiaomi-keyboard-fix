# Xiaomi Pad 7 Keyboard Fix v2.1 — single Magisk module

Install this ZIP in Magisk → Modules → Install from storage, then reboot.
The installer requires ARM64 and /dev/nanodev0. It installs the supplied files
at their original paths immediately; the complete fix starts after reboot.
This package targets the same ROM/kernel/vendor environment as the uploaded
adb.zip. The binaries still depend on that device's vendor libraries and HAL.
The user confirmed the v2.0 keyboard/LED setup works after restoring executable
permissions and its missing marker. Version 2.1 integrates that startup fix.
The new ZIP has been tested in a simulated installation/boot environment;
physical testing of this exact ZIP still requires the tablet.

## v2.1 startup correction

Install over v2.0 in Magisk and reboot; do not uninstall v2.0 first.
There are no terminal commands or hidden startup-marker files to create.

- Global boot launchers check the normal module.prop file rather than the
  missing .keyboard_bundle marker that blocked v2.0 startup.
- Installation verifies executable permissions on scripts and binaries.
- The module's post-fs-data hook restores the complete payload permission list
  every boot, before the authentication and LED launchers run.
- IDC configuration is also applied from the module hook, covering a boot
  where a general post-fs-data script initially lacked executable permission.
- This does not add another authentication/LED launcher; only the existing
  service.d launcher starts the original processes.
- Boot permission-repair status is recorded in /data/adb/kbd/bundle.log.

## Included behavior

- MiDevAuth daemon, original libraries, tokenhelper, and keyboard authentication.
- Caps Lock LED and Ctrl+Alt+3 / Ctrl+Alt+4 backlight controls.
- Connection-aware HID bind/unbind and on-screen-keyboard handling.
- Both original early IDC scripts and the BasicFix system IDC overlay.
- Both original BasicFix boot hooks, including delayed HID rebind and
  SurfaceFlinger 1008 (disable hardware overlays), preserved unchanged.
  Any interaction between these original rebind hooks and reconnect handling
  remains as it was in the supplied setup.

## Installed paths

- /data/adb/kbdauth/: original scripts, IDC text, binaries and libraries.
- /data/adb/service.d/: kbdauth.sh, xiaomi_kbd_service.sh, tokenhelper.
- /data/adb/post-fs-data.d/: kbd_idc.sh and post-fs-data-kbd-idc.sh.
- /data/adb/kbd/: runtime directory; logs/frame/FIFO are created by the scripts.
- /data/adb/modules/basicfix_pad7/: this single consolidated module, including
  system/etc/idc/Vendor_15d9_Product_00a3.idc.
- /data/system/devices/idc/Vendor_15d9_Product_00a3.idc: early input config.
- /data/adb/.pad7_keyboard_bundle/: private original-file backups and ownership
  records for uninstall. Do not delete while the module is installed.

This reuses `basicfix_pad7` so an existing BasicFix installation is replaced,
not run as a second module. Keep only this consolidated version installed.
Original keyboard payloads and BasicFix logic are retained. The only additions
to the four general boot scripts are checks for the bundle being installed,
enabled and not marked for removal. General boot scripts are used deliberately
to preserve the requested folder structure; Magisk normally recommends module
boot scripts instead. Reference: https://topjohnwu.github.io/Magisk/guides.html

## Excluded

cpu-guard.sh, cpu_watchdog.log, XtremeBS, Magisk executables/configuration/database,
and historical logs and transient hframe.bin. Existing unrelated files on the
device are untouched. The LED script's own getevent disconnect watcher remains
part of the supplied keyboard fix; it is unrelated to the personal CPU guard.
No SELinux permissive change or new policy rule is added.

## Disable, remove and reinstall

Disable in Magisk and reboot to stop the bundle's boot scripts and system
mount. The data-side IDC file remains while disabled. Already running services
stop on reboot; toggling the switch alone does not stop them immediately.

Remove in Magisk and reboot to restore overwritten external files or delete
files newly installed by this bundle. Original pre-existing general boot
scripts may therefore resume after removal; this is restoration of your old
manual setup. The replaced BasicFix module itself is not restored on uninstall.
Reinstall its original ZIP if needed. Runtime logs are left intact.

Files edited after installation are preserved rather than overwritten during
uninstall. In that case the private backup directory is retained for recovery.
Reinstallation reapplies the supplied payload and retains the original backup.

The archive did not include a repository URL or keyboard-fix license. Original
author comments and binary bytes are retained; this is a personal repack of the
uploaded files, not a verified upstream release. `source-sha256.json` records
hashes of the source keyboard files. `files.list` records payload destinations
and modes; `managed.list` is generated by the installer.
