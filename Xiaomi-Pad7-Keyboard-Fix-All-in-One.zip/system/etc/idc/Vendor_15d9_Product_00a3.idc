keyboard.layout = Vendor_15d9_Product_00a3
keyboard.characterMap = Generic
keyboard.orientationAware = 0
keyboard.builtIn = 0
device.internal = 0
touch.deviceType = pointer
touch.orientationAware = 0
