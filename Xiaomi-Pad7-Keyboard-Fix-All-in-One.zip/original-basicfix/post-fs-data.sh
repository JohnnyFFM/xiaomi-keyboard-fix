#!/system/bin/sh
MODDIR=${0%/*}
(
  sleep 20
  echo -n "0006:15D9:00A3.0001" > /sys/bus/hid/drivers/hid-generic/unbind 2>/dev/null
  sleep 1
  echo -n "0006:15D9:00A3.0001" > /sys/bus/hid/drivers/hid-generic/bind 2>/dev/null
  service call SurfaceFlinger 1008 i32 1
) &
