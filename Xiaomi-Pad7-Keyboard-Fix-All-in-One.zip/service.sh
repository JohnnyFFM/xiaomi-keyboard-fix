#!/system/bin/sh
MODDIR=${0%/*}
sh "$MODDIR/original-basicfix/service.sh"
