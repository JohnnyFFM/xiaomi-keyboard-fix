#!/system/bin/sh
# Restore only files still matching this bundle; preserve later user edits.
STATE=/data/adb/.pad7_keyboard_bundle
[ ! -L "$STATE" ] && [ -f "$STATE/ready" ] || exit 0
failed=0
while read -r mode rel; do
  target=/data/$rel
  safe=1; check=$target
  while [ "$check" != / ]; do
    [ ! -L "$check" ] || safe=0
    check=${check%/*}; [ -n "$check" ] || check=/
  done
  [ "$safe" = 1 ] || { failed=1; continue; }
  [ -f "$STATE/owned/$rel" ] || { failed=1; continue; }
  if [ -e "$target" ] && ! cmp -s "$target" "$STATE/owned/$rel"; then
    # Keep changed files and their backup for manual recovery.
    failed=1; continue
  fi
  if [ -f "$STATE/backup/$rel" ]; then
    mkdir -p "${target%/*}" || { failed=1; continue; }
    cp -p "$STATE/backup/$rel" "$target" || { failed=1; continue; }
    case "$rel" in
      adb/*) chcon u:object_r:magisk_file:s0 "$target" 2>/dev/null ;;
      system/*) restorecon "$target" 2>/dev/null ;;
    esac
  else
    rm -f "$target" || failed=1
  fi
done < "$STATE/managed.list"
[ "$failed" = 0 ] && rm -rf "$STATE"
# Runtime logs are deliberately left intact; unrelated directories are untouched.
rmdir /data/adb/kbdauth /data/adb/kbd 2>/dev/null
exit 0
